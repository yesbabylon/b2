<?php

define('FTP_HOST',      'IP or hostname');
define('FTP_USERNAME',  'username');
define('FTP_PASSWORD',  'password');
define('FTP_REMOTE_DIR','/path/to/filestore');
