#!/bin/bash
# build a new image with Dockerfile from current directory
docker build -t docked-nginx  .
