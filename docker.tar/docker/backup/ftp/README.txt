These scripts interact directly with FTP server.

Target domain name is expected as single argument and related config file is retrieved by looking under /home/<domain_name>/status/backup/

